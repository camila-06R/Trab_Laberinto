#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>

#define ROWS 21
#define COLS 21

int maze[ROWS][COLS];

int dir[4][2] = {
    {0, 1},   // derecha
    {1, 0},   // abajo
    {0, -1},  // izquierda
    {-1, 0}   // arriba
};

void printMaze() {
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            if (i == 1 && j == 1) {
                printf("T");
            } else if (i == ROWS - 2 && j == COLS - 2) {
                printf("O");
            } else if (maze[i][j] == 1) {
                printf("█");
            } else if (maze[i][j] == 2) {
                printf(".");
            } else {
                printf(" ");
            }
        }
        printf("\n");
    }
    printf("\n");
}

void generateMaze(int x, int y) {
    maze[x][y] = 0;

    int directions[4] = {0, 1, 2, 3};
    for (int i = 0; i < 4; i++) {
        int r = rand() % 4;
        int temp = directions[r];
        directions[r] = directions[i];
        directions[i] = temp;
    }

    for (int i = 0; i < 4; i++) {
        int newX = x + dir[directions[i]][0] * 2;
        int newY = y + dir[directions[i]][1] * 2;

        if (newX >= 0 && newX < ROWS && newY >= 0 && newY < COLS && maze[newX][newY] == 1) {
            maze[x + dir[directions[i]][0]][y + dir[directions[i]][1]] = 0;
            generateMaze(newX, newY);
        }
    }
}

int isValid(int x, int y) {
    return (x >= 0 && x < ROWS && y >= 0 && y < COLS && maze[x][y] == 0);
}

int solveMaze(int x, int y, int *steps) {
    if (x == ROWS - 2 && y == COLS - 2) {
        maze[x][y] = 2;
        printMaze();
        return 1;
    }

    maze[x][y] = 2;
    printMaze();
    usleep(100000);

    for (int i = 0; i < 4; i++) {
        int newX = x + dir[i][0];
        int newY = y + dir[i][1];

        if (isValid(newX, newY)) {
            (*steps)++;
            if (solveMaze(newX, newY, steps)) {
                return 1;
            }
            (*steps)--;
        }
    }

    maze[x][y] = 0;
    return 0;
}

int main() {
    srand(time(NULL));

    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLS; j++) {
            maze[i][j] = 1;
        }
    }

    generateMaze(1, 1);

    int steps = 0;
    if (solveMaze(1, 1, &steps)) {
        printf("Laberinto resuelto en %d movimientos.\n", steps);
    } else {
        printf("No se pudo resolver el laberinto.\n");
    }

    return 0;
}